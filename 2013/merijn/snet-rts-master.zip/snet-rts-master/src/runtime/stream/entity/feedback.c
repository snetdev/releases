/**
 * Feedback Combinator
 *
 * The feedback combinator implements a real feedback loop.
 * Special care must be taken to avoid the situation of
 * artificial deadlock.
 *
 * Author: Daniel Prokesch <daniel.prokesch@gmail.com>
 * Date:   2011-04-11
 */
#include <assert.h>

#include "ast.h"
#include "snetentities.h"

#include "expression.h"
#include "memfun.h"
#include "queue.h"

#include "threading.h"
#include "distribution.h"

/**
 * If following is defined, no buffer entity in the back-channel
 * is created. This can lead to artificial deadlock if there is not enough
 * capacity in streams of the feedback network, for records produced in the
 * feedback loop.
 */
//#define FEEDBACK_OMIT_BUFFER

/**
 * Use the stream-emitter implementation of the feedback buffer
 */
//#define FEEDBACK_STREAM_EMITTER

#define FEEDBACK_BACKCHAN_CAPACITY 64

/* Helper function for the feedback-dispatcher
 * - copied from star.c
 */
static bool MatchesBackPattern( snet_record_t *rec,
    snet_variant_list_t *back_patterns, snet_expr_list_t *guards)
{
  snet_expr_t *expr;
  snet_variant_t *pattern;

  LIST_ZIP_EACH(guards, back_patterns, expr, pattern) {
    if (SNetEevaluateBool( expr, rec) &&
        SNetRecPatternMatches(pattern, rec)) {
      return true;
    }
  }

  return false;
}



/******************************************************************************
 * Feedback collector
 *****************************************************************************/

enum fbcoll_mode {
  FBCOLL_IN,
  FBCOLL_FB1,
  FBCOLL_FB0
};

typedef struct {
  snet_stream_desc_t *instream, *outstream, *backstream;
  bool terminate;
  enum fbcoll_mode mode;
} fbcoll_arg_t;

/* helper functions to handle mode the feedback collector is in */
static void FbCollReadIn(fbcoll_arg_t *fbcarg)
{
  snet_record_t *rec;

  assert( false == fbcarg->terminate );

  /* read from input stream */
  rec = SNetStreamRead( fbcarg->instream);

  switch( SNetRecGetDescriptor( rec)) {

    case REC_data:
      /* relay data record */
      SNetStreamWrite( fbcarg->outstream, rec);
      /* append a sort record */
      SNetStreamWrite(
          fbcarg->outstream,
          SNetRecCreate( REC_sort_end, 0, 1 ) /*type, lvl, num*/
          );
      /* mode switch to FB1 */
      fbcarg->mode = FBCOLL_FB1;
      break;

    case REC_sort_end:
      /* increase the level and forward */
      SNetRecSetLevel( rec, SNetRecGetLevel(rec)+1);
      SNetStreamWrite( fbcarg->outstream, rec);
      break;

    case REC_terminate:
      fbcarg->terminate = true;
      SNetStreamWrite( fbcarg->outstream, rec);
      /* note that no sort record has to be appended */
      break;

    case REC_sync:
      SNetStreamReplace( fbcarg->instream, SNetRecGetStream( rec));
      SNetRecDestroy( rec);
      break;

    case REC_collect:
    default:
      assert(0);
      /* if ignoring, at least destroy ... */
      SNetRecDestroy( rec);
      break;
  }
}


static void FbCollReadFbi(fbcoll_arg_t *fbcarg)
{
  snet_record_t *rec;

  assert( false == fbcarg->terminate );

  /* read from feedback stream */
  rec = SNetStreamRead( fbcarg->backstream);

  switch( SNetRecGetDescriptor( rec)) {

    case REC_data:
      /* relay data record */
      SNetStreamWrite( fbcarg->outstream, rec);
      /* mode switch to FB0 (there is a next iteration) */
      fbcarg->mode = FBCOLL_FB0;
      break;

    case REC_sort_end:
      assert( 0 == SNetRecGetLevel(rec) );
      switch(fbcarg->mode) {
        case FBCOLL_FB0:
          fbcarg->mode = FBCOLL_FB1;
          /* increase counter (non-functional) */
          SNetRecSetNum( rec, SNetRecGetNum(rec)+1);
          SNetStreamWrite( fbcarg->outstream, rec);
          break;
        case FBCOLL_FB1:
          fbcarg->mode = FBCOLL_IN;
          /* kill the sort record */
          SNetRecDestroy( rec);
          break;
        default: assert(0);
      }
      break;

    case REC_sync:
      SNetStreamReplace( fbcarg->backstream, SNetRecGetStream( rec));
      SNetRecDestroy( rec);
      break;

    case REC_terminate:
    case REC_collect:
    default:
      assert(0);
      /* if ignoring, at least destroy ... */
      SNetRecDestroy( rec);
      break;
  }
}

/**
 * The feedback collector, the entry point of the
 * feedback combinator
 */
static void FeedbackCollTask(void *arg)
{
  fbcoll_arg_t *fbcarg = arg;

  /* which stream to read from is mode dependent */
  switch(fbcarg->mode) {
    case FBCOLL_IN:
      FbCollReadIn(fbcarg);
      break;
    case FBCOLL_FB1:
    case FBCOLL_FB0:
      FbCollReadFbi(fbcarg);
      break;
    default: assert(0); /* should not be reached */
  }

  if(fbcarg->terminate){
    SNetStreamClose(fbcarg->instream,   true);
    SNetStreamClose(fbcarg->backstream, true);
    SNetStreamClose(fbcarg->outstream,  false);
    SNetMemFree(fbcarg);
    return;
  }

  SNetThreadingRespawn(NULL);
}


/******************************************************************************
 * Feedback dispatcher
 *****************************************************************************/

typedef struct {
  snet_stream_desc_t *instream, *outstream, *backstream;
  snet_variant_list_t *back_patterns;
  snet_expr_list_t *guards;
} fbdisp_arg_t;

/**
 * The feedback dispatcher, at the end of the
 * feedback combinator
 */
static void FeedbackDispTask(void *arg)
{
  fbdisp_arg_t *fbdarg = arg;

  snet_record_t *rec;

  /* read from input stream */
  rec = SNetStreamRead( fbdarg->instream);

  switch( SNetRecGetDescriptor( rec)) {

    case REC_data:
      /* route data record */
      if( MatchesBackPattern( rec, fbdarg->back_patterns, fbdarg->guards)) {
        /* send rec back into the loop */
        SNetStreamWrite( fbdarg->backstream, rec);
      } else {
        /* send to output */
        SNetStreamWrite( fbdarg->outstream, rec);
      }
      break;

    case REC_sort_end:
      {
        int lvl = SNetRecGetLevel(rec);
        if ( 0 == lvl ) {
          SNetStreamWrite( fbdarg->backstream, rec);
        } else {
          assert( lvl > 0 );
          SNetRecSetLevel( rec, lvl-1);
          SNetStreamWrite( fbdarg->outstream, rec);
        }
      }
      break;

    case REC_terminate:
#ifndef FEEDBACK_OMIT_BUFFER
      /* a terminate record is sent in the backloop for the buffer */
      SNetStreamWrite( fbdarg->backstream, SNetRecCopy( rec));
#endif
      SNetStreamWrite( fbdarg->outstream, rec);
      SNetStreamClose(fbdarg->instream,   true);
      SNetStreamClose(fbdarg->outstream,  false);
      SNetStreamClose(fbdarg->backstream, false);

      SNetMemFree( fbdarg);
      return;

    case REC_sync:
      SNetStreamReplace( fbdarg->instream, SNetRecGetStream( rec));
      SNetRecDestroy( rec);
      break;

    case REC_collect:
    default:
      assert(0);
      /* if ignoring, at least destroy ... */
      SNetRecDestroy( rec);
      break;
  }

  SNetThreadingRespawn(NULL);
}

/******************************************************************************
 * Feedback buffer
 *****************************************************************************/

typedef struct{
  snet_stream_desc_t *instream, *outstream;
  int out_capacity;
#ifdef FEEDBACK_STREAM_EMITTER
  int out_counter;
#else
  snet_queue_t *internal_buffer;
  int max_read;
#endif
} fbbuf_arg_t;

#ifdef FEEDBACK_STREAM_EMITTER
static void FeedbackBufTask(void *arg)
{
  fbbuf_arg_t *fbbarg = arg;

  snet_record_t *rec;

  rec = SNetStreamRead(fbbarg->instream);
  if( SNetRecGetDescriptor(rec) == REC_terminate ) {
    /* this means, the outstream does not exist anymore! */
    SNetRecDestroy(rec);
    SNetStreamClose(fbbarg->instream,  true);
    SNetStreamClose(fbbarg->outstream, false);
    SNetMemFree(fbbarg);
    return;
  }

  if (fbbarg->out_counter+1 >= fbbarg->out_capacity) {
    /* new stream */
    snet_stream_t *new_stream = SNetStreamCreate(fbbarg->out_capacity);
    SNetStreamWrite(fbbarg->outstream,
        SNetRecCreate(REC_sync, new_stream)
        );

    SNetStreamClose(fbbarg->outstream, false);
    fbbarg->outstream = SNetStreamOpen(new_stream, 'w');
    fbbarg->out = new_stream;
    fbbarg->out_counter = 0;
  }
  /* write the record to the stream */
  SNetStreamWrite(fbbarg->outstream, rec);
  fbbarg->out_counter++;

  SNetThreadingRespawn(NULL);
}

#else /* FEEDBACK_STREAM_EMITTER */

/**
 * The feedback buffer
 */
static void FeedbackBufTask(void *arg)
{
  fbbuf_arg_t *fbbarg = arg;

  snet_record_t *rec;
  int out_capacity;
  int n = 0;
  int max_read = fbbarg->max_read;

  out_capacity =  fbbarg->out_capacity;

  rec = NULL;

  /* STEP 1: read n=min(available,max_read) records from input stream */

  /* read first record of the actual dispatch */
  if (0 == SNetQueueSize(fbbarg->internal_buffer)) {
    rec = SNetStreamRead(fbbarg->instream);
    /* only in empty mode! */
    if( REC_terminate == SNetRecGetDescriptor( rec)) {
      /* this means, the outstream does not exist anymore! */
      SNetRecDestroy(rec);
      SNetQueueDestroy(fbbarg->internal_buffer);

      SNetStreamClose(fbbarg->instream,   true);
      SNetStreamClose(fbbarg->outstream,  false);
      SNetMemFree(fbbarg);
      return;
    }
  } else {
    SNetThreadingYield();
    if ( SNetStreamPeek(fbbarg->instream) != NULL ) {
      rec = SNetStreamRead(fbbarg->instream);
      assert( REC_terminate != SNetRecGetDescriptor( rec) );
    }
  }

  if (rec != NULL) {
    n = 1;
    /* put record into internal buffer */
    (void) SNetQueuePut(fbbarg->internal_buffer, rec);
  }


  while ( n<=max_read && SNetStreamPeek(fbbarg->instream)!=NULL ) {
    rec = SNetStreamRead(fbbarg->instream);

    /* check if we will need a larger outstream, and if so,
     * create a larger stream
     */
    if (SNetQueueSize(fbbarg->internal_buffer)+1 >= out_capacity) {
      snet_stream_t *new_stream;
      out_capacity *= 2;

      new_stream = SNetStreamCreate(out_capacity);
      (void) SNetQueuePut(fbbarg->internal_buffer,
                          SNetRecCreate(REC_sync, new_stream));
    }

    /* put record into internal buffer */
    (void) SNetQueuePut(fbbarg->internal_buffer, rec);
    n++;
  }

  /* STEP 2: try to empty the internal buffer */
  rec = SNetQueuePeek(fbbarg->internal_buffer);

  while (rec != NULL) {
    snet_stream_t *new_stream = NULL;
    if( REC_sync == SNetRecGetDescriptor( rec)) {
      new_stream = SNetRecGetStream(rec);
    }
    if (0 == SNetStreamTryWrite(fbbarg->outstream, rec)) {
      snet_record_t *rem;
      /* success, also remove from queue */
      rem = SNetQueueGet(fbbarg->internal_buffer);
      assert( rem == rec );

      if (new_stream != NULL) {
        /* written sync record, now change stream */
        SNetStreamClose(fbbarg->outstream, false);
        fbbarg->outstream = SNetStreamOpen(new_stream, 'w');
      }
    } else {
      /* there remain elements in the buffer */
      break;
    }
    /* for the next iteration */
    rec = SNetQueuePeek(fbbarg->internal_buffer);
  }
  fbbarg->out_capacity = out_capacity;

  SNetThreadingRespawn(NULL);
}
#endif /* FEEDBACK_STREAM_EMITTER */

/****************************************************************************/
/* CREATION FUNCTION                                                        */
/****************************************************************************/
snet_stream_t *SNetFeedbackInst( snet_stream_t *input,
    snet_info_t *info,
    snet_locvec_t *locvec,
    int location,
    snet_variant_list_t *back_patterns,
    snet_expr_list_t *guards,
    snet_ast_t *box_a)
{
  snet_stream_t *output;

  input = SNetRouteUpdate(info, input, location);
  if (SNetDistribIsNodeLocation(location)) {
    snet_stream_t *into_op, *from_op;
    snet_stream_t *back_bufin, *back_bufout;
    fbbuf_arg_t *fbbarg;
    fbcoll_arg_t *fbcarg;
    fbdisp_arg_t *fbdarg;

    /* create streams */
    into_op = SNetStreamCreate(0);
    output  = SNetStreamCreate(0);
    back_bufout = SNetStreamCreate(FEEDBACK_BACKCHAN_CAPACITY);


#ifndef FEEDBACK_OMIT_BUFFER
    back_bufin  = SNetStreamCreate(0);

    /* create the feedback buffer */
    fbbarg = SNetMemAlloc( sizeof( fbbuf_arg_t));
    fbbarg->instream = SNetStreamOpen(back_bufin, 'r');
    fbbarg->outstream = SNetStreamOpen(back_bufout, 'w');
    fbbarg->out_capacity = FEEDBACK_BACKCHAN_CAPACITY;
#ifdef FEEDBACK_STREAM_EMITTER
    fbbarg->out_counter = 0;
#else /* FEEDBACK_STREAM_EMITTER */
    fbbarg->max_read = fbbarg->out_capacity; /* TODO better usual stream capacity */
    fbbarg->internal_buffer = SNetQueueCreate();
#endif /* FEEDBACK_STREAM_EMITTER */
    SNetThreadingSpawn( ENTITY_fbbuf, location, SNetNameCreate(locvec, SNetIdGet(info),
          "<fbbuf>"), &FeedbackBufTask, fbbarg);
#else
    back_bufin = back_bufout;
#endif

    /* create the feedback collector */
    fbcarg = SNetMemAlloc( sizeof( fbcoll_arg_t));
    fbcarg->terminate = false;
    fbcarg->instream = SNetStreamOpen(input, 'r');
    fbcarg->outstream = SNetStreamOpen(into_op, 'w');
    fbcarg->backstream = SNetStreamOpen(back_bufout, 'r');
    fbcarg->mode = FBCOLL_IN;
    SNetThreadingSpawn( ENTITY_fbcoll, location, SNetNameCreate(locvec, SNetIdGet(info),
          "<fbcoll>"), &FeedbackCollTask, fbcarg);

    /* create the instance network */
    from_op = SNetInstantiate(box_a, into_op, info);
    from_op = SNetRouteUpdate(info, from_op, location);

    /* create the feedback dispatcher */
    fbdarg = SNetMemAlloc( sizeof( fbdisp_arg_t));
    fbdarg->instream = SNetStreamOpen(from_op, 'r');
    fbdarg->outstream = SNetStreamOpen(output, 'w');
    fbdarg->backstream = SNetStreamOpen(back_bufin, 'w');
    fbdarg->back_patterns = back_patterns;
    fbdarg->guards = guards;
    SNetThreadingSpawn( ENTITY_fbdisp, location, SNetNameCreate(locvec, SNetIdGet(info),
          "<fbdisp>"), &FeedbackDispTask, fbdarg);

  } else {
    SNetVariantListDestroy(back_patterns);
    SNetExprListDestroy(guards);
    output = SNetInstantiate(box_a, input, info);
    output = SNetRouteUpdate(info, output, location);
  }

  return output;
}

snet_ast_t *SNetFeedback(int location,
                         snet_variant_list_t *back_patterns,
                         snet_expr_list_t *guards,
                         snet_startup_fun_t box_a)
{
  snet_ast_t *result = SNetMemAlloc(sizeof(snet_ast_t));
  result->location = location;
  result->type = snet_feedback;
  result->locvec.type = LOC_FEEDBACK;
  result->locvec.num = -1;
  result->locvec.parent = NULL;
  result->feedback.back_patterns = back_patterns;
  result->feedback.guards = guards;
  result->feedback.box_a = box_a(location);
  result->feedback.box_a->locvec.parent = &result->locvec;
  return result;
}
