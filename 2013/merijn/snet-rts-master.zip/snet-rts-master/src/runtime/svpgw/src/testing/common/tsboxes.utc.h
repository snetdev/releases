#include "snet.utc.h"

#define T 0
#define PRINT_STDOUT  

#define LOAD_THRESSHOLD 1
// #define LOAD_THRESSHOLD 10000000

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

extern int SNetCall__A(snet_handle_t *hnd, void *field_a);
extern int SNetCall__B(snet_handle_t *hnd, void *field_b);
extern int SNetCall__C(snet_handle_t *hnd, void *field_c);
extern int SNetCall__D(snet_handle_t *hnd, void *field_d);
extern int SNetCall__E(snet_handle_t *hnd, void *field_e);

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

