#ifndef STREAM_H
#define STREAM_H

typedef struct snet_stream_t snet_stream_t;

#endif /* STREAM_H */
