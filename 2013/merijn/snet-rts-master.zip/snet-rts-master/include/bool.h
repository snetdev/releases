/*
 * Datatype Boolean
 */

#ifndef _SNETC_TYPES_H_ /* in case this gets included when building snetc */

#ifndef BOOL_H
#define BOOL_H

typedef int bool;
#define false 0
#define true  1

#endif /* BOOL_H */

#endif /* _SNETC_TYPES_H_  */
