#ifndef _ADD_H_
#define _ADD_H_

#include <C4SNet.h>

void *add( void *hnd, c4snet_data_t *state, c4snet_data_t *inval);

#endif /* _ADD_H */

