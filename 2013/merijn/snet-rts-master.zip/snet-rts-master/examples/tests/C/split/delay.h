#ifndef _DELAY_H_
#define _DELAY_H_

#include <C4SNet.h>

void *delay( void *hnd, c4snet_data_t *x, int T);

#endif /* _DELAY_H_ */

