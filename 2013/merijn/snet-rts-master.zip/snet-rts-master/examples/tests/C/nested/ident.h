#ifndef IDENT_H_
#define IDENT_H_

#include "C4SNet.h"

void *ident( void *hnd, c4snet_data_t *x, int T);

#endif /* IDENT_H_ */

