#ifndef SUB_H_
#define SUB_H_

#include "C4SNet.h"

void *dec( void *hnd, c4snet_data_t *x);

#endif /* SUB_H_ */

