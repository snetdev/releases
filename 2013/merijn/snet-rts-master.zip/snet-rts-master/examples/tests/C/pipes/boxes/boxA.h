#ifndef BOXA_H_
#define BOXA_H_ 

#include <C4SNet.h>

void *boxA( void *hnd, int a);

#endif /* BOXA_H_ */

