#ifndef BOXB_H_
#define BOXB_H_ 

#include <C4SNet.h>

void *boxB( void *hnd, int a);

#endif 

