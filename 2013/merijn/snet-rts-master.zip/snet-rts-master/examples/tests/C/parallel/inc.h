#ifndef INC_H_
#define INC_H_ 

#include <C4SNet.h>

void *inc( void *hnd, c4snet_data_t *x);

#endif /* INC_H_ */

