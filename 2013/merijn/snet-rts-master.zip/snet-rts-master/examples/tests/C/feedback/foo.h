#ifndef FOO_H_
#define FOO_H_ 

#include <C4SNet.h>

void *foo( void *hnd, c4snet_data_t *x, int counter);

#endif /* FOO_H_ */

