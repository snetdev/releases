#ifndef INIT_H_
#define INIT_H_

#include "C4SNet.h"

void *init(void *hnd);

#endif /* INIT_H_ */

