
Run the example with the environment variable MMAP set to the placement
of the multithreaded mmul box (see the gigo.snet source).

$ MMAP=-1,2,4 ./gigo-lpel <input2.xml

See sac4snet.txt in the top-level directory for more info.
