#ifndef _computeOpts_h_
#define _computeOpts_h_

#include <SAC2SNet.h>

void *computeOpts( void *hnd, void *ptr);


#endif
