#ifndef _solveOneLevel_h_
#define _solveOneLevel_h_

#include <SAC2SNet.h>

void *solveOneLevel( void *hnd, void *ptr_1, void *ptr_2);


#endif
