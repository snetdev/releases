#ifndef _SUB_H_
#define _SUB_H_

#include <C4SNet.h>

void *sub( void *hnd, c4snet_data_t *x);

#endif /* _SUB_H_ */
