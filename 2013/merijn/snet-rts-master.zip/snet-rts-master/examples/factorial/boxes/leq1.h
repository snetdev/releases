#ifndef _LEQ1_H_
#define _LEQ1_H_

#include <C4SNet.h>

void *leq1( void *hnd, c4snet_data_t *x);

#endif /* _LEQ1_H_ */
