#ifndef _MULT_H_
#define _MULT_H_

#include <C4SNet.h>

void *mult( void *hnd, c4snet_data_t *x, c4snet_data_t *r);

#endif /* _MULT_H_ */
