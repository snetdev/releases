#ifndef _CONDIF_H_
#define _CONDIF_H_

#include <C4SNet.h>

void *condif( void *hnd, c4snet_data_t *x);

#endif /* _CONDIF_H_ */
