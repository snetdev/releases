#ifndef _KeyInvert_h_
#define _KeyInvert_h_

#include <SAC4SNet.h>

void *KeyInvert( void *hnd, void *ptr_1);

#endif

