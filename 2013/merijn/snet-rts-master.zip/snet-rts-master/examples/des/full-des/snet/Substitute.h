#ifndef _Substitute_h_
#define _Substitute_h_

#include <SAC4SNet.h>

void *Substitute( void *hnd, void *ptr_1);

#endif
