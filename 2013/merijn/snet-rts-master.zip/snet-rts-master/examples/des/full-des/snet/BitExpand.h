#ifndef _BitExpand_h_
#define _BitExpand_h_

#include <SAC4SNet.h>

void *BitExpand( void *hnd, void *ptr_1);

#endif
