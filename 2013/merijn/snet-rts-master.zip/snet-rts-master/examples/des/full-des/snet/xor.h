#ifndef _xor_h_
#define _xor_h_

#include <SAC4SNet.h>

void *xor( void *hnd, void *ptr_1, void *ptr_2);


#endif
