#ifndef _SubKey_h_
#define _SubKey_h_

#include <SAC4SNet.h>

void *SubKey( void *hnd, void *ptr_1, int tag);

#endif
