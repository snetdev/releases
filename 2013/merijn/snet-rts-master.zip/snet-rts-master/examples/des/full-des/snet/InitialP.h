#ifndef _InitialP_h_
#define _InitialP_h_

#include <SAC4SNet.h>

void *InitialP( void *hnd, void *ptr_1);


#endif
