#ifndef _Pbox_h_
#define _Pbox_h_

#include <SAC4SNet.h>

void *Pbox( void *hnd, void *ptr_1);

#endif
