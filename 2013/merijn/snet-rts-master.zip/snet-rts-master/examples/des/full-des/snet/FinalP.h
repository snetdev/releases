#ifndef _FinalP_h_
#define _FinalP_h_

#include <SAC4SNet.h>

void *FinalP( void *hnd, void *ptr_1, void *ptr_2);

#endif
