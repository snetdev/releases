#ifndef SPLIT_H_
#define SPLIT_H_

#include <C4SNet.h>

void *split( void *hnd, c4snet_data_t *A, int A_width, int A_height, int nodes);

#endif /* SPLIT_H_ */
