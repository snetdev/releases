#ifndef INIT_H_
#define INIT_H_

#include <C4SNet.h>

void *init( void *hnd, c4snet_data_t *array, int C_width, int C_height, int last);

#endif /* INIT_H_ */
