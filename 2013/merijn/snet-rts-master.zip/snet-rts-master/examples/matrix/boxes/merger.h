#ifndef MERGER_H_
#define MERGER_H_

#include <C4SNet.h>

void *merger( void *hnd, c4snet_data_t *C, c4snet_data_t *c, int C_width, int C_height, int first, int last);

#endif /* MERGER_H_ */
