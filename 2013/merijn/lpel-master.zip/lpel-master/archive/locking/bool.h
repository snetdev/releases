/*
 * Datatype Boolean
 */


#ifndef BOOL_H
#define BOOL_H

typedef int bool;
#define false 0
#define true  1

#endif /* BOOL_H */

