
#include <lpel.h>

/* Keep copy of the (checked) configuration provided at LpelInit() */
lpel_config_t    _lpel_global_config;

